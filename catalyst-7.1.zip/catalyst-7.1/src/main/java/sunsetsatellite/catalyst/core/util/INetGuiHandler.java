package sunsetsatellite.catalyst.core.util;

public interface INetGuiHandler {

	void handleOpenGui(PacketOpenGui packet);
}
