package sunsetsatellite.catalyst.fluids.interfaces.mixins;


import sunsetsatellite.catalyst.fluids.mp.packets.PacketFluidWindowClick;

public interface INetServerHandler {
    void handleFluidWindowClick(PacketFluidWindowClick p);
}
