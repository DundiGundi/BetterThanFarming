package sunsetsatellite.catalyst.effects.api.effect;

public enum EffectDisplayPlace {
	INVENTORY,
	HUD,
	BOTH
}
