package sunsetsatellite.catalyst.effects.api.effect;

public interface IHasEffects {
	EffectContainer<?> getContainer();
}
