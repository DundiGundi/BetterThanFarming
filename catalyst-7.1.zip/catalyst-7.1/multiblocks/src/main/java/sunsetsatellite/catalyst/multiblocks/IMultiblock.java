package sunsetsatellite.catalyst.multiblocks;

public interface IMultiblock {
    Multiblock getMultiblock();
}
